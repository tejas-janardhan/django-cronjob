from django.test import TestCase


# Create your tests here.

class TestJobModel(TestCase):

     def setUp(self):


class TestJobGroupModel(TestCase):
    pass


class TestJobHistoryModel(TestCase):
    pass
